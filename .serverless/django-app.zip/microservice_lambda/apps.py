from django.apps import AppConfig


class MicroserviceLambdaConfig(AppConfig):
    name = 'microservice_lambda'
